CREATE TABLE IF NOT EXISTS fcc_team_accounts (
 user_id INT UNSIGNED PRIMARY KEY,
 primary_user_id INT UNSIGNED NOT NULL,
 fbo_id CHAR(12) NOT NULL,
 active TINYINT UNSIGNED NOT NULL DEFAULT 1,
 version INT UNSIGNED NOT NULL DEFAULT 1,
 actor_user_id INT UNSIGNED NOT NULL,
 updated_at DATETIME NOT NULL,
 KEY shared_identity(fbo_id,active,primary_user_id),
 KEY shared_accounts(primary_user_id,active,user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
